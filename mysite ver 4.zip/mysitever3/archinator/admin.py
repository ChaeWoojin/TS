from django.contrib import admin
from .models import Part, Category

# Register your models here.
class CategoryInline(admin.StackedInline):
    model = Category
    extra = 8

class CategoryAdmin(admin.ModelAdmin):
    fieldsets=[]
    inlines = [CategoryInline]

admin.site.register(Part)
admin.site.register(Category, CategoryAdmin)