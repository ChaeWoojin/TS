from django.apps import AppConfig


class ArchinatorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'archinator'
