from django.apps import AppConfig


class HospotConfig(AppConfig):
    name = 'hospot'
