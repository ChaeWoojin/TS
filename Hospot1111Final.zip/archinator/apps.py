from django.apps import AppConfig


class ArchinatorConfig(AppConfig):
    name = 'archinator'
