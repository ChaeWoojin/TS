
class KEY():
    key='django-insecure-l520naese+nm^qu8&zq)%a_9!zt*795t5o$h1z(!ykdif0)0cg'
